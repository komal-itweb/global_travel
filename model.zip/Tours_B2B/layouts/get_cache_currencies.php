<?php
if (file_exists('../cache.txt')) {
    $modified_time = filemtime('cache.txt');
}else{
    $modified_time = time()-1*10801;
}
$data = array();
if ($modified_time < time()-1*10800) {
    include_once '../model/model.php';
    
    //Currency Rates
    $result = mysql_query("SELECT * FROM roe_master");
    while($row = mysql_fetch_array($result)) {
        $temp_array = array(
            'entry_id' => $row['entry_id'],
            'currency_id' => $row['currency_id'],
            'currency_rate' => $row['currency_rate']
        );
        array_push($data,$temp_array);
    }
    //Currency Icon
    $sq_currency= mysql_query("select default_currency,id from currency_name_master");
    while($row_currency = mysql_fetch_array($sq_currency)) {
        $temp_array = array(
            'icon' => $row_currency['default_currency'],
            'id' => $row_currency['id']
        );
        array_push($data,$temp_array);
    }

    $result = mysql_query("SELECT * FROM tax_master");
    while($row = mysql_fetch_array($result)) {
        $temp_array = array(
            'entry_id' => $row['entry_id'],
            'name' => $row['name'],
            'rate_in' => $row['rate_in'],
            'rate' => $row['rate'],
            'status' => $row['status']
        );
        array_push($data,$temp_array);
    }
    //Tax Rules
    $result = mysql_query("SELECT * FROM tax_master_rules");
    while($row = mysql_fetch_array($result)) {
        $temp_array = array(
            'rule_id' => $row['rule_id'],
            'entry_id' => $row['entry_id'],
            'name' => $row['name'],
            'validity' => $row['validity'],
            'from_date' => $row['from_date'],
            'to_date' => $row['to_date'],
            'ledger_id' => $row['ledger_id'],
            'travel_type' => $row['travel_type'],
            'calculation_mode' => json_encode($row['calculation_mode']),
            'target_amount' => $row['target_amount'],
            'applicableOn' => $row['applicableOn'],
            'conditions' => $row['conditions'],
            'status' => $row['status']
        );
        array_push($data,$temp_array);
    }

    // store query result in cache.txt
    file_put_contents('../cache.txt', serialize(json_encode($data)));
    $data = json_encode($data);
}
else {
    $data = unserialize(file_get_contents('cache.txt'));
    //echo $data;
}
?>