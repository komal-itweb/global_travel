<?
include_once('../model.php');
 function employee_sign_up_mail($first_name, $last_name, $username, $password, $email_id)
{
  global $app_email_id, $app_name, $app_contact_no, $admin_logo_url, $app_website;
  global $mail_em_style, $mail_em_style1, $mail_font_family, $mail_strong_style, $mail_color;
   $link = BASE_URL.'view/customer';
  $content = mail_login_box($username, $password, $link);

  global $model;
  $subject = "Welcome Aboard";
  $model->app_email_master($email_id, $content, $subject,'1');
}


?>