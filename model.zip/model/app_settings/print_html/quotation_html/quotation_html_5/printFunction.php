
<!DOCTYPE html>
<html>
<head>
	<title>.</title>

	<link href="https://fonts.googleapis.com/css?family=Noto+Sans" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,500" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo BASE_URL ?>css/font-awesome-4.7.0/css/font-awesome.min.css">
  
  <link rel="stylesheet" type="text/css" href="<?php echo BASE_URL ?>css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="<?= BASE_URL ?>css/app/admin.php">
  <link rel="stylesheet" type="text/css" href="<?= BASE_URL ?>css/app/app.php">
  <link rel="stylesheet" media="print" href="<?= BASE_URL ?>css/print/quotationGeneric.php"/>
  <link rel="stylesheet" media="print" href="<?= BASE_URL ?>css/print/printQuotationfive/quotationPrint.php"/>
	<link rel="stylesheet" media="print" href="<?= BASE_URL ?>css/print/printQuotationfive/quotationPdf.css"/>

<script src="<?= BASE_URL ?>js/jquery-3.1.0.min.js"></script>
<script src="<?= BASE_URL ?>js/jquery-ui.min.js"></script>
<script src="<?= BASE_URL ?>js/bootstrap.min.js"></script>

<script type="text/javascript">
  $(document).ready(function () {
     window.print();
  });
</script>

</head>
<body>